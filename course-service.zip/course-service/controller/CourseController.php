<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 11/28/2017
 * Time: 7:29 PM
 */

class CourseController
{
    public function __construct()
    {
    }

    function processInternal(&$data, $param)
    {
        if (empty($param)){
            $this->getAll($data);
            return;
        }

        $id = $param[0];
        $this->get($data, $id);
    }

    protected function getAll(&$data){
        $dao = new CourseDao();
        $courses = $dao->getAll();
        $data["courses"] = $courses;
    }

    protected function get(&$data, $id){
        $dao = new CourseDao();
        $course = $dao->get($id);
        if($course == null){
            return;
        }
        $data["course"] = $course;
        $data["requestedId"] = $id;
    }
}