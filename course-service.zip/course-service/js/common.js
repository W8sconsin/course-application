$(function(){
    $(document).on('click','a',function(event){//binds listener to image link, clears content on click instead of actually going anywhere
        event.preventDefault();
        $("#content").empty();
    });
    $(document).on('click','a.course-listing',function(event){
        event.preventDefault();
        $("#content").empty();
        $.ajax({
            url: "courses",
            type: "GET",
            dataType: "json",
            cache: false,
            success: function(response){
                try{
                    var courses = response.courses;
                    if (courses){
                        var data = "";
                        data +="<table><tr><th>Id</th>";
                        data += "<th>Course Name</th>"
                        data += "<th>Description</th></tr>"
                        students.forEach(function(element){
                            data += "<tr>"
                            data += "<td>" + element.id + "</td>";
                            data += "<td>" + element.courseName + "</td>";
                            data += "<td>" + element.description + "</td>";
                            data += "<td>" + " <a href='course/" + element.id + "' class='detail'>Detail</a> " +"</td>";
                            data += "<br />";
                        });
                        $("#content").html(data);
                    }else{
                        $("#content").html("No courses found.");
                    }
                }catch (ex){
                    $("#content").html("Error Parsing: " +ex);
                }
            },
            error: function(response){
                $("#content").html("Nothing found.");
            },
            accepts: "application/json"
        });
    });
    $("#searchBtn").click(function(event){//note, button is not named yet.
        //$("#content").text("Hurray!"); test only
        //search function goes here
        search();
    });
});

function search(){
    var searchKey = $('#search').val();//make course daos section dao textbook dao and models for each and coursedetail model
  /*  $.ajax({
        url: "course/" + searchKey,
        type: "GET",
        dataType: "json",
        cache: false,
    var result = "First Name:";
    result += "<input type ='text' id='fname' value=''/> <br />"
    result += "Last Name:"
    result += "<input type ='text' id='lname' value=''/> <br />"
    result += "Email:"
    result += "<input type ='text' id='email' value=''/> <br />"
    result += "Phone Number:"
    result += "<input type ='text' id='phone' value=''/> <br />"
    result += "Your Comment:"
    result += "<textarea maxlength='500' name='comment' id='comment'></textarea> <br />"//how to set this to a text area??? with max 200 char
    result += "<input type ='button' id='submitBtn' value='Submit'/> <br />"

    $("#content").html(result);*/
}