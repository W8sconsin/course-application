<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 11/28/2017
 * Time: 6:18 PM
 */

class Course implements JsonSerializable
{
    private $id;
    private $courseName;
    private $description;

    public function __construct(String $id, String $courseName, String $description)
    {
        $this->courseName = $courseName;
        $this->description = $description;
        $this->id = $id;
    }

    /**
     * @return String
     */
    public function getId(): String
    {
        return $this->id;
    }

    /**
     * @param String $id
     */
    public function setId(String $id)
    {
        $this->id = $id;
    }

    /**
     * @return String
     */
    public function getCourseName(): String
    {
        return $this->courseName;
    }

    /**
     * @param String $courseName
     */
    public function setCourseName(String $courseName)
    {
        $this->courseName = $courseName;
    }

    /**
     * @return String
     */
    public function getDescription(): String
    {
        return $this->description;
    }

    /**
     * @param String $description
     */
    public function setDescription(String $description)
    {
        $this->description = $description;
    }





    public function jsonSerialize()//maps JSON string
    {
        return ["id"=> $this->id,
            "courseName"=> $this->courseName,
            "description"=> $this->description];
    }
}