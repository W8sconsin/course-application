<?php
/**
 * User: lyang
 * Date: 9/7/17
 */

class CourseDao
    /**
     * Returns an array of Color objects.  Empty array is returned if none exist.
     * @return array
     */
{
    public function __construct()
    {
    }
    public function getAll() {
        $sql = "select * from course order by id";
        $rows = Db::queryAll($sql, array());
        $result = array();
        if(empty($rows)){
            return $result;
        }
        foreach($rows as $row){
            $course = $this->create($row);
            array_push($result, $course);
        }
        return $result;
    }
    private function create($row){
        return new Course($row["id"], $row["courseName"], $row["description"]);
    }

}